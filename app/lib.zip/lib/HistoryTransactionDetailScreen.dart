import 'package:flutter/material.dart';
import 'package:msb/notifier/TransactionNotifier.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';

class HistoryTransactionDetailScreen extends StatelessWidget {
  String convertDatetime(DateTime date) {
    var formattedDate = DateFormat.yMMMd().format(date);
    return formattedDate.toString();
  }

  Widget build(BuildContext context) {
    TransactionNotifier transactionNotifier =
        Provider.of<TransactionNotifier>(context, listen: false);
    // TODO: implement build
    var deviceHeight = MediaQuery.of(context).size.height;
    var deviceWidth = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: Text('Product Detail'),
        elevation: 0.0,
      ),
      body: new SafeArea(
        child: Stack(
          alignment: Alignment.centerLeft,
          fit: StackFit.expand,
          children: <Widget>[
            Column(
              children: <Widget>[
                Container(
                  height: deviceHeight * 0.2,
                  width: deviceWidth,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage('assets/LOGO_PERUSAHAAN_MSB.png'),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(
                      horizontal: deviceWidth * 0.02,
                      vertical: deviceHeight * 0.04),
                  child: Column(
                    children: <Widget>[
                      RichText(
                        text: TextSpan(
                          text: transactionNotifier.currentTransaction.id,
                          style: TextStyle(color: Colors.black, fontSize: 20),
                        ),
                      ),
                      RichText(
                        text: TextSpan(
                          text: convertDatetime(
                              transactionNotifier.currentTransaction.date),
                          style: TextStyle(color: Colors.black, fontSize: 20),
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: deviceWidth * 0.02,
                            vertical: deviceHeight * 0.04),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            RichText(
                              textAlign: TextAlign.left,
                              text: TextSpan(
                                style: TextStyle(color: Colors.black),
                                text: "Expected Price",
                              ),
                            ),
                            RichText(
                              textAlign: TextAlign.right,
                              text: TextSpan(
                                style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold),
                                text: "150.000",
                              ),
                            ),
                            RichText(
                              text: TextSpan(
                                style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold),
                                text: "-",
                              ),
                            ),
                            RichText(
                              text: TextSpan(
                                style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold),
                                text: "200.000",
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  child: ListView.builder(
                    physics: ScrollPhysics(),
                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                    itemCount:
                        transactionNotifier.currentTransaction.products.length,
                    itemBuilder: (BuildContext context, int index) =>
                        transactionNotifier
                                    .currentTransaction.products.length !=
                                null
                            ? Card(
                                borderOnForeground: true,
                                child: InkWell(
                                  splashColor: Colors.blue.shade300,
                                  onTap: () {},
                                  child: Container(
                                    height:
                                        MediaQuery.of(context).size.height / 8,
                                    width: MediaQuery.of(context).size.width,
                                    child: new ListTile(
                                      title: int.parse(transactionNotifier
                                                  .currentTransaction
                                                  .products[index]
                                                  .stock) >
                                              1
                                          ? Text(transactionNotifier
                                                  .currentTransaction
                                                  .products[index]
                                                  .stock
                                                  .toString() +
                                              ' Items')
                                          : Text(transactionNotifier
                                                  .currentTransaction
                                                  .products[index]
                                                  .stock
                                                  .toString() +
                                              ' Item'),
                                      subtitle: Text(
                                          transactionNotifier.currentTransaction
                                              .products[index].name,
                                          textAlign: TextAlign.center),
                                    ),
                                  ),
                                ),
                              )
                            : Center(child: Text("No data")),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
