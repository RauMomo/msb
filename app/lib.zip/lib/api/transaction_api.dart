import 'package:msb/model/ProductModel.dart';
import 'package:msb/notifier/TransactionNotifier.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:msb/model/TransactionModel.dart';
import 'product_api.dart';

Transactions transaction = new Transactions();
String str = "";
getPendingTransactionList(TransactionNotifier transactionNotifier) async {
  QuerySnapshot snapshot = await FirebaseFirestore.instance
      .collection('transactions')
      .where('transaction_status', isEqualTo: 'Pending')
      .get();

  str = FirebaseFirestore.instance.collection('transactions').doc().id;
  List<Transactions> transactionList = List<Transactions>();
  snapshot.docs.forEach((document) {
    Transactions transaction = Transactions(
        date: (document.get('transaction_date') as Timestamp).toDate(),
        email: document.get('transaction_email'),
        id: str,
        supplier: document.get('transaction_supplier'),
        products: List<Product>.from(
            document.data()['transaction_products'].map((item) {
          return Product(
              name: item['product_name'],
              stock: item['product_stock'],
              // price: determinePrice(item['product_name']));
              price: 50000);
        })).toList(),
        invoice: document.get('transaction_invoice'),
        status: document.get('transaction_status'),
        totalPrice: document.get('transaction_total_price'),
        totalProduct: document.get('transaction_total_product'));
    transactionList.add(transaction);
  });
  transactionNotifier.pendingTransactionList = transactionList;
}

getSuccessTransactionList(TransactionNotifier transactionNotifier) async {
  QuerySnapshot snapshot = await FirebaseFirestore.instance
      .collection('transactions')
      .where('transaction_status', isEqualTo: 'Verified')
      .get()
      .catchError((onError) {
    print('error');
  });
  str = FirebaseFirestore.instance.collection('transactions').doc().id;

  List<Transactions> transactionList = List<Transactions>();
  snapshot.docs.forEach((document) {
    Transactions transaction = Transactions(
        date: (document.get('transaction_date') as Timestamp).toDate(),
        email: document.get('transaction_email'),
        id: str,
        supplier: document.get('transaction_supplier'),
        products: List<Product>.from(
            document.data()['transaction_products'].map((item) {
          return Product(
              name: item['product_name'],
              stock: item['product_stock'],
              price: determinePrice(item['product_name']));
        })).toList(),
        invoice: document.get('transaction_invoice'),
        status: document.get('transaction_status'),
        totalPrice: document.get('transaction_total_price'),
        totalProduct: document.get('transaction_total_product'));
    transactionList.add(transaction);
  });
  transactionNotifier.successTransactionList = transactionList;
}
