import 'package:flutter/material.dart';
import 'package:msb/model/ProductModel.dart';

class ProductCard extends StatefulWidget {
  const ProductCard({Key key, @required this.product}) : super(key: key);
  final Product product;
  @override
  _ProductCardState createState() => _ProductCardState();
}

class _ProductCardState extends State<ProductCard> {
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      margin: EdgeInsets.fromLTRB(20, 20, 20, 20),
      width: double.infinity,
      height: MediaQuery.of(context).size.height * 0.15,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 7,
              offset: Offset(1, 1))
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                margin: EdgeInsets.fromLTRB(20, 10, 0, 10),
                child: Text(widget.product.name,
                    style: TextStyle(
                        fontFamily: "Segoe_UI_Bold",
                        fontSize: 18,
                        fontWeight: FontWeight.w500)),
              ),
              Container(
                margin: EdgeInsets.fromLTRB(10, 0, 0, 0),
                alignment: Alignment.center,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text("Asking Price",
                        style: TextStyle(
                            fontFamily: "Segoe_UI_Bold",
                            fontSize: 17,
                            fontWeight: FontWeight.w500,
                            height: 1.5)),
                    Text(widget.product.price.toString(),
                        style: TextStyle(
                            fontFamily: "Segoe_UI_Bold",
                            fontSize: 17,
                            fontWeight: FontWeight.w500,
                            height: 1.5)),
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.27,
                      height: 35,
                      child: Container(
                        margin: EdgeInsets.only(left: 35),
                        child: Material(
                          borderRadius: BorderRadius.circular(20),
                          color: Colors.transparent,
                          child: InkWell(
                            borderRadius: BorderRadius.circular(20),
                            splashColor: Colors.amber,
                            onTap: () {},
                            child: Center(
                                child: Text(
                              "Edit",
                              style: TextStyle(
                                  fontFamily: "Segoe_UI_Bold",
                                  fontSize: 17,
                                  fontWeight: FontWeight.w500),
                            )),
                          ),
                        ),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: Colors.lightBlueAccent,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                alignment: Alignment.centerLeft,
                margin: EdgeInsets.fromLTRB(5, 5, 0, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text("Total Price",
                        style: TextStyle(
                            fontFamily: "Segoe_UI_Bold",
                            fontSize: 17,
                            fontWeight: FontWeight.w500,
                            height: 1.5)),
                    Text("    " + widget.product.totalPrice.toString(),
                        style: TextStyle(
                            fontFamily: "Segoe_UI_Bold",
                            fontSize: 17,
                            fontWeight: FontWeight.w500,
                            height: 1.5)),
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.27,
                      height: 35,
                      child: Container(
                        margin: EdgeInsets.only(left: 35),
                        child: Material(
                          borderRadius: BorderRadius.circular(20),
                          color: Colors.transparent,
                          child: InkWell(
                            borderRadius: BorderRadius.circular(20),
                            splashColor: Colors.amber,
                            onTap: () {},
                            child: Center(
                                child: Text(
                              "Delete",
                              style: TextStyle(
                                  fontFamily: "Segoe_UI_Bold",
                                  fontSize: 17,
                                  fontWeight: FontWeight.w500),
                            )),
                          ),
                        ),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: Colors.red,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
