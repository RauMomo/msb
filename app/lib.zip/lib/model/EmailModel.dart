class Email {
  String email;
  Email({this.email});
}
