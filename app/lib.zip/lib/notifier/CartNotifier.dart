import 'dart:async';
import 'dart:collection';

import 'package:flutter/material.dart';
import 'package:msb/model/ProductModel.dart';

class CartNotifier with ChangeNotifier {
  List<Product> _cartList = [];
  int _totalPrice = 0;

  set cartList(List<Product> cartList) {
    _cartList = cartList;
  }

  UnmodifiableListView<Product> get cartList => UnmodifiableListView(_cartList);

  set totalPrice(int totalPrice) {
    _totalPrice = calculateTotalProduct();
    notifyListeners();
  }

  int get totalPrice => _totalPrice;

  void addItemtoCart(Product prod) {
    bool isFound = false;
    int result;
    if (_cartList.length > 0) {
      for (int count = 0; count < _cartList.length; count++) {
        if (prod.name == _cartList[count].name) {
          isFound = true;
          result = int.parse(_cartList[count].stock);
          result++;
          _cartList[count].stock = result.toString();
          _cartList[count].totalPrice =
              calculatePrice(_cartList[count].price, _cartList[count].stock);
          break;
          //  else if (prod.name == _cartList[count].name && isFound == true) {
          //   _cartList.removeAt(count);
        } else if (count == _cartList.length - 1) {
          _cartList.add(new Product(
              name: prod.name,
              price: prod.price,
              stock: 1.toString(),
              totalPrice: prod.price));
          break;
        }
      }
    } else {
      _cartList.add(new Product(
          name: prod.name,
          price: prod.price,
          stock: 1.toString(),
          totalPrice: prod.price));
    }
    notifyListeners();
  }

  void removeItemfromCart(Product prod) {
    _cartList.remove(prod);
    notifyListeners();
  }

  int calculateTotalProduct() {
    int price = 0;
    if (_cartList.isNotEmpty) {
      _cartList.forEach((prod) {
        price += (prod.price * int.parse(prod.stock));
      });
      return price;
    } else
      return 0;
  }

  int calculatePrice(int price, String stock) {
    return price * int.parse(stock);
  }
  // CartNotifier() {
  //   // cartStreamController.stream.listen(addItemtoCart);
  //   // cartStreamController.stream.listen(removeItemtoCart);
  // }
  // void dispose() {
  //   cartStreamController.close();
  // }
}
