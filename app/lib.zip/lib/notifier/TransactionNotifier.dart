import 'dart:collection';

import 'package:flutter/cupertino.dart';
import 'package:msb/model/TransactionModel.dart';

class TransactionNotifier with ChangeNotifier {
  List<Transactions> _pendingTransactionList = [];
  List<Transactions> _successTransactionList = [];
  Transactions _currentTransaction;

  UnmodifiableListView<Transactions> get pendingTransactionList =>
      UnmodifiableListView(_pendingTransactionList);

  UnmodifiableListView<Transactions> get successTransactionList =>
      UnmodifiableListView(_successTransactionList);

  Transactions get currentTransaction => _currentTransaction;

  set pendingTransactionList(List<Transactions> pendingTransactionList) {
    _pendingTransactionList = pendingTransactionList;
    notifyListeners();
  }

  set successTransactionList(List<Transactions> successTransactionList) {
    _successTransactionList = successTransactionList;
    notifyListeners();
  }

  set currentTransaction(Transactions currentTransaction) {
    _currentTransaction = currentTransaction;
    notifyListeners();
  }
}
