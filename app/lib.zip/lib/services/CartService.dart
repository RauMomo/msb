// import 'dart:async';

// import 'package:msb/model/ProductModel.dart';

// class CartService {
//   StreamController<List<Product>> _streamController =
//       StreamController<List<Product>>();
//   Stream<List<Product>> get
//   double total = 0.0;
// }
